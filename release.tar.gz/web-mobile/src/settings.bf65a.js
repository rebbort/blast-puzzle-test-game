window._CCSettings = {
    platform: "web-mobile",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    hasResourcesBundle: true,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/scenes/GameScene.fire",
    orientation: "",
    debug: true,
    jsList: [],
    bundleVers: {
        internal: "d36c4",
        resources: "2ea58",
        main: "b93b5"
    }
};
